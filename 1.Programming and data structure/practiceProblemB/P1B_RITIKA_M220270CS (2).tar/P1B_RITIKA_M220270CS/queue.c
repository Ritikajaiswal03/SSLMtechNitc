#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"list.h" 
#include"queue.h"

void enQueue(struct Course *cs,int x,char *str){
	struct dllnode* temp;
	struct dllnode *ptr = (struct dllnode*)malloc(sizeof(struct dllnode));
	strcpy(ptr->st_name,str);
	if(cs[x].waitList == NULL){
		ptr->next = NULL;  
        ptr->prev = NULL;  
        cs[x].waitList = ptr; 
	}
	else{
		temp = cs[x].waitList;  
        while(temp->next!=NULL)  
        {  
            temp = temp->next;  
        }  
        temp->next = ptr;  
        ptr ->prev=temp;  
        ptr->next = NULL;  
	}
	printf("\n Please Wait!,You are in the waiting List\n"); 
}

void deQueue(struct Course *cs,int x){
	char str[20];
	struct dllnode* ptr;
	if(cs[x].waitList == NULL)  
    {  
        printf("\n UNDERFLOW\n");  
    }  
    else if(cs[x].waitList->next == NULL)  
    {  
    	strcpy(str,cs[x].waitList->st_name);
    	Sortedinsert(cs,x,str);
        cs[x].waitList = NULL;   
        free(cs[x].waitList);   
    }  
    else  
    {  
    	strcpy(str,cs[x].waitList->st_name);
    	Sortedinsert(cs,x,str);
        ptr = cs[x].waitList;  
        cs[x].waitList = cs[x].waitList -> next;  
        cs[x].waitList -> prev = NULL;  
        free(ptr);   
    }  
}

void isEmptyQueue(struct Course *cs,int x){
	if(cs[x].waitList == NULL)  
    {  
        printf("Waiting List is Empty \n");  
    }
    else printf("%d Students in Waiting List\n",cs[x].ct);
}
