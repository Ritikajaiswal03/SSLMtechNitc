#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"list.h"
#include"queue.h"

void Sortedinsert(struct Course *cs,int x,char *str){
	if(cs[x].ct < cs[x].max_Limit){
	struct StudentNode *curr;
	struct StudentNode *ptr = (struct StudentNode*)malloc(sizeof(struct StudentNode));
	strcpy(ptr->st_name,str);
	if(cs[x].regList == NULL || strcasecmp(cs[x].regList->st_name ,ptr->st_name)>=0){
		ptr->next = cs[x].regList;
		cs[x].regList = ptr;
		cs[x].ct++;
	}
	else{
		curr = cs[x].regList;
		while(curr->next!=NULL && strcasecmp(curr->next->st_name , ptr->st_name)<=0){
			curr = curr->next;
		}
		ptr->next = curr->next;
		curr->next = ptr;
		cs[x].ct++;
	}
	
	}
	else{
		enQueue(cs,x,str);
	}
}

void delete(struct Course *cs,int y){
	struct StudentNode *temp = cs[y].regList;
	struct StudentNode *prev = NULL;
	char nm[20];
	char str[20] = "";
	
	printf("Enter your name\n");
	scanf("%s",nm);
	
	if(temp == NULL) printf("List is Empty");
	else{
		if(temp != NULL && !strcmp(temp->st_name,nm)){
			cs[y].regList = temp->next;
			free(temp);
			printf("Your name deleted Successfully from course.\n");
			cs[y].ct--;
		}
		else{
			while(temp!=NULL && strcmp(temp->st_name, nm)){
				prev = temp;
				temp = temp->next;
			}
			if(temp == NULL) return;
			prev->next = temp->next;
			free(temp);
			printf("Your name deleted Successfully from course\n");
			cs[y].ct--;
		}	
	}
	
	if(cs[y].ct < cs[y].max_Limit){
		deQueue(cs,y);
	}

}


