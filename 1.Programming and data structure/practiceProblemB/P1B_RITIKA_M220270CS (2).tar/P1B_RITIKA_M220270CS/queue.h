struct dllnode{   
    struct dllnode *prev;   
    char st_name[20];  
    struct dllnode *next;   
}; 

void enQueue(struct Course *cs,int x,char *str);
void deQueue(struct Course *cs,int x);
void isEmptyQueue(struct Course *cs,int x);
