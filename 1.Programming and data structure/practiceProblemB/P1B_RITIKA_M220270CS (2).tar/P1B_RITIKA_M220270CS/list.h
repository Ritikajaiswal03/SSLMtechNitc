struct StudentNode{
	char st_name[20];
	struct StudentNode *next;
};

struct Course{
	char code[10];
	char name[3];
	int credits;
	int max_Limit;
	struct StudentNode* regList;
	struct dllnode* waitList;
	int ct;
};

void Sortedinsert(struct Course *cs,int x,char *str);
void delete(struct Course *cs,int y);
