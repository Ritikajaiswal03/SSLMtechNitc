#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"list.h" 
#include"queue.h" 

void createList(struct Course s[],int n){
	int i ;
	for(i = 0;i<n;i++){
		printf("Enter course code,name and credits respectively;\n");
		scanf("%s%s%d",s[i].code,s[i].name,&s[i].credits);
		s[i].regList = NULL;
		s[i].ct = 0;
		s[i].waitList = NULL;
		printf("Enter maximum limit for this course:\n");
		scanf("%d",&s[i].max_Limit);
	}
	
}

int CourseValid(struct Course *cs,char *cos,int n){
	int i = 0;
	for(i =0;i<n;i++){
		int value = strcmp(cs[i].code,cos);
		if(value == 0) return i;
	}
	return -1;

}

void display(struct Course *cs,int n){
	int i = 0;
	for(i = 0;i<n;i++){
		printf("%d.%s :--\n",i+1,cs[i].name);
		while(cs[i].regList!=NULL){
		printf("  %s\n",cs[i].regList->st_name);
		cs[i].regList = cs[i].regList->next;
		}
		printf("Number of students registered: %d\n",cs[i].ct);
		isEmptyQueue(cs,i);
	}
	
}

int main(){
	struct Course cs[100];
	int n,x,y;
	int choice;
	int ch = 1;
	char cos[20];
	printf("How many courses you want to add:\n");
	scanf("%d",&n);
	createList(cs,n);
	
while(ch>0){

	printf("Choose an option from below:\n");
	printf("1. Registering your name in Course:\n");
	printf("2. deleting your name from course:\n");
	scanf("%d",&choice);
	switch(choice){
	case 1: printf("Enter the course in which you want to enroll:\n");
		scanf("%s",cos);
		x = CourseValid(cs,cos,n);
		char nm[20];
		printf("Enter name to add\n");
		scanf("%s",nm);
		if(x>=0){
			Sortedinsert(cs,x,nm);
		}
		else printf("Not a Valid Course\n");
		strcpy(cos,"");
		break;
		
	case 2: printf("Enter the course from which you want to delete your name:\n");
		scanf("%s",cos);
		y = CourseValid(cs,cos,n);
		if(y>=0){
			delete(cs,y);
		}
		else printf("Not a Valid Course\n");
		strcpy(cos,"");
		break;
		
	default : printf("wrong choice , Please Enter a valid Choice\n");
		  break;
	}
	
	printf("Do you want to Continue: if no, type 0\n");
	scanf("%d",&ch);	
	
}
	display(cs,n);
	return 0;
}
