#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct bst{
	struct bst *parent;
	char name[20];
	struct bst *left;
	struct bst *right;
};

struct Course{
	char code[10];
	char name[3];
	int credits;
	struct bst *regList;
};

struct stack{
	struct bst* name;
	struct stack* next;
};

void createList(struct Course *cs,int n){
	int i = 0;
	for(i = 0;i<n;i++){
		printf("Enter course code,course name,and course credits:\n");
		scanf("%s%s%d",cs[i].code,cs[i].name,&cs[i].credits);
		cs[i].regList = NULL;
	}
	
}

int coursevalid(struct Course *cs,char *cde,int n){
	int i = 0;
	for(i = 0;i<n;i++){
		if(strcmp(cs[i].code,cde)==0) return i;	
	}
	return -1;
}
struct bst* treeMinimum(struct bst *x){
	while(x->left!=NULL){
		x = x->left;
	}
	return x;
}

void insert(char *ch,struct bst **t){
	struct bst *ptr = (struct bst*)malloc(sizeof(struct bst));
	strcpy(ptr->name,ch);
	ptr->left = NULL;
	ptr->parent = NULL;
	ptr->right = NULL;
	
	struct bst *y = NULL;
	struct bst *x = NULL;
	x = *t;
	if(x == NULL){
		*t = ptr;
	}
	else{
		while(x!=NULL){
			y = x;
			if(strcmp(ptr->name,x->name)<0){
				x = x->left;
			}else x = x->right;
		}
		ptr->parent = y;
		if(strcmp(ptr->name,y->name)<0){
			y->left = ptr;
		} 
		else y->right = ptr;
	}
}

struct bst* deleted(struct bst *t,char *ch){
	if(t == NULL) return t;
	else if(strcmp(ch,t->name)<0) t->left = deleted(t->left,ch);
	else if(strcmp(ch,t->name)>0) t->right = deleted(t->right,ch);
	else{
		if(t->left == NULL && t->right == NULL){
			free(t);
			t = NULL;
		}
		else if(t->left == NULL){
			struct bst *temp = t;
			t = t->right;
			free(temp);
		}
		else if(t->right == NULL){
			struct bst *temp = t;
			t = t->left;
			free(temp);
		}
		else{
			struct bst *temp = treeMinimum(t->right);
			strcpy(t->name,temp->name);
			t->right = deleted(t->right,temp->name);
		}
	}
	return t;
}

void push(struct stack** top,struct bst* n){
	struct stack* new_n = (struct stack*)malloc(sizeof(struct stack));
	new_n->name = n;
	new_n->next = (*top);
	(*top) = new_n;
}

int isEmpty(struct stack* top){
	if(top == NULL) return 1;
	else return 0;
}

struct bst* pop(struct stack** top_n){
	struct bst* item;
	struct stack* top;
	top = *top_n;
	item = top->name;
	*top_n = top->next;
	free(top);
	return item;
}

void inorderTreeWalkWoR(struct bst *t){
	struct bst* temp = t;
	struct stack* s_temp = NULL;
	int flag = 1;
	while(flag){
		if(temp){
			push(&s_temp,temp);
			temp = temp->left;
		}
		else{
			if(!isEmpty(s_temp)){
				temp = pop(&s_temp);
				printf("%s ",temp->name);
				temp = temp->right;
			}
			else flag = 0;
		}
	}
}

void inorderTreeWalk(struct bst *t){
	if(t!=NULL){
		inorderTreeWalk(t->left);
		printf("%s ",t->name);
		inorderTreeWalk(t->right);
	}
}

void printRegList(char *c,int n,struct Course *arr){
	int x,i = 0;
	for(i = 0;i<n;i++){
		if(strcmp(arr[i].code,c)==0){
			x = i;
			inorderTreeWalk(arr[i].regList);
			break;
		}	
	}
	
}

void printRegListWoR(char *c,int n,struct Course *arr){
	int x,i = 0;
	for(i = 0;i<n;i++){
		if(strcmp(arr[i].code,c)==0){
			x = i;
			inorderTreeWalkWoR(arr[i].regList);
			break;
		}	
	}
	
}

int main(){
	int n;
	printf("Enter number of courses you want to add:\n");
	scanf("%d",&n);
	struct Course arr[20];
	createList(arr,n);
	
	int choice;
	char str[10];
	char cor[30];
	int ch = 1;
	while(ch){
	printf("Enter your choice:\n");
	printf("1.Registering in course\n");
	printf("2.Deleting your name from course\n");
	printf("3.Display all details\n");
	printf("4.Display all details without recursion\n");
	
	scanf("%d",&choice);
	switch(choice){
		case 1:printf("Enter the course code in which you want to register your name:\n");
			scanf("%s",str);
			int x = coursevalid(arr,str,n);
			if(x == -1) printf("Course code invalid\n");
			else{
				char nm[20];
				printf("Enter name to add\n");
				scanf("%s",nm);
				insert(nm,&(arr[x].regList));
			}
			break;
			
		case 2: printf("Enter the course code from which you want to delete your name\n");
			scanf("%s",str);
			int y = coursevalid(arr,str,n);
			if(y == -1) printf("Course code invalid\n");
			else{
				char nm[20];
				printf("Enter name to delete\n");
				scanf("%s",nm);
				arr[y].regList = deleted(arr[y].regList,nm);
			}
			break;
		case 3:printf("Enter course code for fetching the student nodes:\n");	
			scanf("%s",cor);
			printRegList(cor,n,arr);
			break;
			
		case 4:printf("Enter course code for fetching the student nodes:\n");	
			scanf("%s",cor);
			printRegListWoR(cor,n,arr);
			break;	
		
		default:printf("Enter correct choice\n");
			break;
	}
	printf("Do you want to continue, otherwise enter 0\n");
	scanf("%d",&ch);
	}
	
	
	return 0;
}
